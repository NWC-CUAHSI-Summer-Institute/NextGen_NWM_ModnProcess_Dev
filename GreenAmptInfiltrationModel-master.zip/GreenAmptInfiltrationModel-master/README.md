# GreenAmptInfiltrationModel
The Green-Ampt method of infiltration estimation

##Obtain first release
The first release, 0.1, is deposited in Zenodo (http://dx.doi.org/10.5281/zenodo.18772).

[![DOI](https://zenodo.org/badge/doi/10.5281/zenodo.18772.svg)](http://dx.doi.org/10.5281/zenodo.18772)
